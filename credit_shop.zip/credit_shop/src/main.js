import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// 完整引入element-ui
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)

//依赖注入 省市区三级联动选择器
import VueAreaLinkage from 'vue-area-linkage'
import 'vue-area-linkage/dist/index.css'
Vue.use(VueAreaLinkage)

import MyHeader from './components/MyHeader'
// import MyFooter from './components/MyFooter';
import base from './assets/css/base.css'
import '@/assets/icon/iconfont.css'

// 将对象变为全局组件
Vue.component('my-header', MyHeader)

//用import语法引入axios模块(node_modules里的不需加路径)
import axios from 'axios'

//将axios对象强行添加到Vue的原型对象中(强行赋值):
Vue.prototype.axios = axios

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
