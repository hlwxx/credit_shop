import Vue from 'vue'
import Router from 'vue-router'

import Index from './views/Index'
import Products from './views/pages/goods/Products.vue'
import Detail from './views/pages/goods/Detail.vue'
import Personal from './views/pages/personal_center/Personal.vue'
import Account from './views/pages/personal_center/Account.vue'
import ChangePhone from './views/pages/personal_center/ChangePhone.vue'
import Address from './views/pages/personal_center/Address.vue'
import Register from './views/pages/Register.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  // base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      component: Index
    },
    {
      path: '/products',
      component: Products
    },
    {
      path: '/detail',
      component: Detail
    },
    {
      path: '/personal',
      component: Personal
    },
    {
      path: '/account',
      component: Account
    },
    {
      path: '/changePhone',
      component: ChangePhone
    },
    {
      path: '/address',
      component: Address
    },
    {
      path: '/register',
      component: Register
    }
  ]
})
