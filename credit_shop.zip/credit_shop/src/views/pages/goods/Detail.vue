<!-- <h1>产品详情页</h1> -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <div id="container">
      <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>潮流数码</el-breadcrumb-item>
        <el-breadcrumb-item>U盘</el-breadcrumb-item>
      </el-breadcrumb>
      <div id="top">
        <!-- 放大镜子组件 -->
        <my-magnify :previewImg="img.md" :zoomImg="img.lg"></my-magnify>

        <div id="icon_sImg">
          <!-- <i class="el-icon-caret-left"></i> -->
          <div id="sm">
            <img v-for="(elem,i) of pics" :key="i" :src="elem.sm" @mouseenter="changeImg(i)" />
            <!-- <i class="el-icon-caret-right"></i> -->
          </div>
          <div id="operation">
            <!-- <img src="../../../../public/images/detail/detail_icon/share.png" />分享给朋友 -->
            <img src="../../../../public/images/detail/detail_icon/collect.png" />收藏产品
          </div>
        </div>
        <div id="specs">
          <div class="title">U盘正品大容量</div>
          <div class="subtitle">
            <span id="credit" class="name">
              积&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;分：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <span>1000</span>
              <span>积分</span>
            </span>
            <p id="explain" class="border_top name">
              说&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;明：
              <span>该产品暂不支持7天无理由退换货</span>
            </p>
          </div>
          <div id="choice">
            <div class="size">
              <span class="nameSpace">尺</span>
              <span class="name">寸：</span>
              <el-radio v-model="radio1" label="1" border>尺寸1</el-radio>
              <el-radio v-model="radio1" label="2" border>尺寸2</el-radio>
              <el-radio v-model="radio1" label="3" border>尺寸3</el-radio>
            </div>
            <div class="format">
              <span class="nameSpace">规</span>
              <span class="name">格：</span>
              <el-radio v-model="radio2" label="1" border>规格1</el-radio>
              <el-radio v-model="radio2" label="2" border>规格2</el-radio>
              <el-radio v-model="radio2" label="3" border>规格3</el-radio>
              <el-radio v-model="radio2" label="4" border>规格4</el-radio>
            </div>
            <div class="thick">
              <span class="nameSpace">厚</span>
              <span class="name">度：</span>
              <el-radio v-model="radio3" label="1" border>厚度1</el-radio>
            </div>
            <div class="number">
              <span class="nameSpace">数</span>
              <span class="name">量：</span>
              <el-input-number v-model="num1" :min="1"></el-input-number>
            </div>
          </div>
          <div id="btn">
            <el-button type="primary" plain>立即兑换</el-button>
            <el-button type="primary" icon="el-icon-shopping-cart-2">
              <!-- <img src="../../../../public/images/detail/detail_icon/cart.png" /> -->
              加入购物车
            </el-button>
          </div>
        </div>
      </div>
      <!-- 1.2 中间'同类推荐' -->
      <div id="refer">
        <p class="title">同类推荐</p>
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <router-link to="/Detail.vue" class="borderProduct">
                <img src="../../../../public/images/products/products_p1.png" />
                <div class="product_text">
                  <p class="product_title">标题1</p>
                  <p class="credit">1积分</p>
                </div>
              </router-link>
            </div>
            <div class="swiper-slide">
              <router-link to="/Detail.vue" class="borderProduct">
                <img src="../../../../public/images/products/products_p1.png" />
                <div class="product_text">
                  <p class="product_title">标题2</p>
                  <p class="credit">2积分</p>
                </div>
              </router-link>
            </div>
            <div class="swiper-slide">
              <router-link to="/Detail.vue" class="borderProduct">
                <img src="../../../../public/images/products/products_p1.png" />
                <div class="product_text">
                  <p class="product_title">标题3</p>
                  <p class="credit">3积分</p>
                </div>
              </router-link>
            </div>
            <div class="swiper-slide">
              <router-link to="/Detail.vue" class="borderProduct">
                <img src="../../../../public/images/products/products_p1.png" />
                <div class="product_text">
                  <p class="product_title">标题4</p>
                  <p class="credit">4积分</p>
                </div>
              </router-link>
            </div>
          </div>
          <div class="swiper-pagination"></div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
      <!-- 1.3 详情及右侧竖列产品 -->
      <div id="detail_product">
        <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
          <el-tab-pane label="商品详情" name="first">
            <img src="../../../../public/images/detail/detail_img/detail0.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail1.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail2.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail3.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail4.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail5.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail6.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail7.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail8.jpg" />
            <img src="../../../../public/images/detail/detail_img/detail9.jpg" />
          </el-tab-pane>
          <el-tab-pane label="兑换说明" name="second">兑换说明</el-tab-pane>
        </el-tabs>
        <div id="boxFixed" :class="{'is_fixed' : isFixed}">
          <p>热门兑换</p>
          <router-link to="/Detail.vue">
            <img src="../../../../public/images/products/products_p1.png" />
            <div class="product_text">
              <p class="product_title">标题1</p>
              <p class="credit">1积分</p>
              <p class="count">已兑换1个</p>
            </div>
          </router-link>
          <router-link to="/Detail.vue">
            <img src="../../../../public/images/products/products_p1.png" />
            <div class="product_text">
              <p class="product_title">标题2</p>
              <p class="credit">2积分</p>
              <p class="count">已兑换2个</p>
            </div>
          </router-link>
          <router-link to="/Detail.vue">
            <img src="../../../../public/images/products/products_p1.png" />
            <div class="product_text">
              <p class="product_title">标题3</p>
              <p class="credit">3积分</p>
              <p class="count">已兑换3个</p>
            </div>
          </router-link>
          <router-link to="/Detail.vue">
            <img src="../../../../public/images/products/products_p1.png" />
            <div class="product_text">
              <p class="product_title">标题4</p>
              <p class="credit">4积分</p>
              <p class="count">已兑换4个</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
// 引入放大镜子组件
import MyMagnify from '../../../components/Magnify.vue'
export default {
  data() {
    return {
      // 热门兑换吸顶固定定位的初始化
      isFixed: false,
      offsetTop: 0,

      // 规格选项初始化(默认不选中)
      radio1: '',
      radio2: '',
      radio3: '',
      // 计数器按钮初始化
      num1: 0,
      // 详情tab初始化
      activeName: 'first',
      // 当前图片(默认显示第一个)
      img: {
        md: require('../../../../public/images/detail/main_img/md/md_img1.jpg'),
        lg: require('../../../../public/images/detail/main_img/lg/lg_img1.jpg')
      },
      // 放大镜图片数组
      pics: [
        {
          sm: require('../../../../public/images/detail/main_img/sm/sm_img1.jpg'),
          md: require('../../../../public/images/detail/main_img/md/md_img1.jpg'),
          lg: require('../../../../public/images/detail/main_img/lg/lg_img1.jpg')
        },
        {
          sm: require('../../../../public/images/detail/main_img/sm/sm_img2.jpg'),
          md: require('../../../../public/images/detail/main_img/md/md_img2.jpg'),
          lg: require('../../../../public/images/detail/main_img/lg/lg_img2.jpg')
        },
        {
          sm: require('../../../../public/images/detail/main_img/sm/sm_img3.jpg'),
          md: require('../../../../public/images/detail/main_img/md/md_img3.jpg'),
          lg: require('../../../../public/images/detail/main_img/lg/lg_img3.jpg')
        },
        {
          sm: require('../../../../public/images/detail/main_img/sm/sm_img4.jpg'),
          md: require('../../../../public/images/detail/main_img/md/md_img4.jpg'),
          lg: require('../../../../public/images/detail/main_img/lg/lg_img4.jpg')
        },
        {
          sm: require('../../../../public/images/detail/main_img/sm/sm_img5.jpg'),
          md: require('../../../../public/images/detail/main_img/md/md_img5.jpg'),
          lg: require('../../../../public/images/detail/main_img/lg/lg_img5.jpg')
        }
      ]
    }
  },
  components: {
    // 放大镜子组件
    MyMagnify
  },
  mounted() {
    // 热门兑换吸顶效果--在mounted钩子中给window添加一个滚动滚动监听事件
    window.addEventListener('scroll', this.initHeight)
    this.$nextTick(() => {
      this.offsetTop = document.querySelector('#boxFixed').offsetTop
    })

    //DOM树挂在完后加载轮播图的方法
    this.initCarousel()
  },
  methods: {
    // 热门兑换吸顶效果--在methods方法中，添加这个initHeight方法
    initHeight() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop
      this.isFixed = scrollTop > this.offsetTop ? true : false
    },
    // 轮播图的方法
    initCarousel() {
      var swiper = new Swiper('.swiper-container', {
        // 是否自动播放
        // autoplay: true,
        // 一屏展示几个
        slidesPerView: 4,
        spaceBetween: 16,
        hideOnClick: true,
        loop: true,
        loopFillGroupWithBlank: true,
        // 分页指示器
        // pagination: {
        //   el: '.swiper-pagination',
        //   clickable: false
        // },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      })
    },
    // 详情tab切换的方法
    handleClick(tab, event) {
      console.log(tab, event)
    },
    // 当鼠标进入主图的对应小图时，切换对应的中图和大图
    changeImg(index) {
      this.img.md = this.pics[index].md
      this.img.lg = this.pics[index].lg
    }
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 0.统一样式 */
* {
  margin: 0;
  padding: 0;
}
body {
  width: 100%;
  background-color: #ffffff !important;
}
#main {
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #eeeeee;
}
#container {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
/* 3.1 面包屑+主图及右侧规格 */
#container #breadcrumb {
  padding-left: 10px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
#container #breadcrumb {
  font-size: 12px !important;
  margin-bottom: 20px;
}
#top {
  width: 1200px;
}
#top img {
  width: 429px;
  height: 429px;
  border: 1px solid #eeeeee;
}
#icon_sImg {
  width: 429px;
  height: 73px;
}

#sm {
  width: 429px;
  height: 73px;
  margin-top: 20px;
}
#sm img {
  width: 71px;
  height: 71px;
  float: left;
  margin-right: 16px;
}
#sm img:last-child {
  margin-left: 0px !important;
  margin-right: 0px !important;
}
#operation {
  font-size: 14px;
  margin: 20px 220px 40px 10px;
  width: 429px;
}
#operation img {
  border: 0;
  width: 16px;
  height: 16px;
  margin-bottom: -3px;
  padding-right: 10px;
}
#operation img:last-child {
  padding-left: 20px;
}

#specs {
  width: 736px;
  height: 560px;
  float: right;
  margin-top: -528px;
}
#specs .title {
  font-size: 22px;
  color: #333333;
}
.subtitle {
  width: 736px;
  height: 120px;
  font-size: 14px;
  color: #666666;
  margin-top: 30px;
  background-color: #eef3f8;
}
#credit {
  margin-left: 20px;
  position: relative;
  top: 20px;
}
#credit span {
  color: #ef4141;
}
#credit span:first-child {
  font-size: 24px;
}
.border_top {
  border-top: 1px solid #dddddd;
  width: 696px;
  margin: 0 auto;
  margin-top: 40px;
  padding-top: 20px;
}
.subtitle p span:first-child {
  margin-left: 28px;
}

#explain {
  padding-bottom: 20px;
}
#choice {
  width: 736px;
  margin: 30px 197px 10px 20px;
}
#choice div {
  padding-bottom: 12px;
}
.name {
  font-size: 14px;
  color: #666666;
}
#choice .nameSpace {
  font-size: 14px;
  color: #666666;
  letter-spacing: 20px;
}
#choice .name {
  margin-right: 20px;
}
#choice .el-radio {
  width: 96px !important;
  height: 36px !important;
  margin-right: 10px;
}

.el-radio.is-bordered {
  color: #333333 !important;
  border-color: #dddddd;
}
.el-radio.is-bordered.is-checked {
  border-color: #6aaee8;
  color: #333333 !important;
}

.number {
  margin-top: 18px;
}
.el-input-number {
  line-height: 32px;
}
::v-deep .el-input-number .el-input__inner {
  height: 36px !important;
}
::v-deep .el-input-number__decrease {
  height: 34px !important;
}
::v-deep .el-input-number__increase {
  height: 34px !important;
}

#btn {
  margin-left: 20px;
}
#btn button {
  width: 168px;
  height: 50px;
  font-size: 18px;
  border-color: #428bca;
}
#btn button:first-child {
  margin-right: 4px;
  color: #428bca;
}
#btn button:last-child {
  background-color: #428bca;
}
#btn img {
  width: 24px;
  height: 21px;
  border: 0;
}
/* 3.2 中间'同类推荐'样式 */
#refer {
  width: 1200px;
  height: 450px;
  margin-top: 80px;
  border: 1px solid #eeeeee;
}
#refer .title {
  height: 48px;
  line-height: 48px;
  background-color: #f5f5f5;
  padding-left: 31px;
}
/* swiper轮播图 */
.swiper-container {
  width: 100%;
  /* height: 100%; */
  height: 396px;
}
.swiper-slide {
  text-align: center;
  font-size: 18px;
  background: #fff;
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
  /* width: 264px !important; */
}
.swiper-wrapper {
  width: 1104px;
  /* height: 396px; */
}

.swiper-slide img {
  width: 264px;
  height: 264px;
  margin-top: 10px;
  margin-bottom: 5px;
}

.borderProduct {
  border: 1px solid #eeeeee;
}
.product_text {
  font-size: 14px;
  margin-top: 8px;
  margin-bottom: 15px;
}
.product_title {
  color: #333333;
  /* margin-bottom: 13px; */
  font-weight: bold;
}
.credit {
  color: #ef4949;
}
.swiper-container-horizontal > .swiper-pagination-bullets,
.swiper-pagination-custom,
.swiper-pagination-fraction {
  bottom: -4px;
  z-index: 100;
}
.swiper-button-prev,
.swiper-button-next {
  /* width: 12px; */
  /* height: 22px; */
  background-color: rgba(221, 214, 214, 0.6);
  border-radius: 50%;
  width: 25px;
  height: 25px;
}
.swiper-button-prev {
  margin-left: -11px;
}
.swiper-button-next {
  margin-right: -11px;
}
/* 3.3 详情的样式 */
#detail_product {
  margin-top: 60px;
  display: flex;
  justify-content: space-between;
}

.el-tabs.el-tabs--top.el-tabs--border-card {
  width: 832px;
}
::v-deep .el-tabs__nav-scroll {
  height: 46px;
  background-color: #f5f5f5;
}
::v-deep .el-tabs--border-card > .el-tabs__header .el-tabs__item {
  height: 46px;
}

::v-deep .el-tabs--border-card > .el-tabs__header .el-tabs__item {
  color: #333333 !important;
}
::v-deep .el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  color: #428bca !important;
}

#boxFixed {
  width: 328px;
  text-align: center;
  border: 1px solid #eeeeee;
  background-color: #ffffff !important;
  /* 设置固定定位： */
  /* position: fixed;
  right: 349px;
  top: 0; */
}
#boxFixed > p:first-child {
  width: 328px;
  height: 46px;
  line-height: 46px;
  text-align: center;
  background-color: #f5f5f5;
}
#boxFixed img {
  width: 200px;
  height: 200px;
  border: 1px solid #eeeeee;
  text-align: center;
  margin-top: 12px;
}
.credit:after {
  content: '';
  width: 120px;
  height: 1px;
  background-color: #eeeeee;
  position: absolute;
  margin-top: 30px;
  margin-left: -84px;
}
#refer .credit:after {
  content: '' !important;
  background: none;
}
#boxFixed .count {
  font-size: 14px;
  color: #999999;
  margin-top: 12px;
}
/* 热门兑换吸顶固定定位的样式 */
.is_fixed {
  position: fixed;
  top: 0;
  left: 64.3%;
}
</style>