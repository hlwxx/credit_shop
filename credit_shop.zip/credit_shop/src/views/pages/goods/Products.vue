<!-- <h1>商品列表页</h1> -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
      <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>潮流数码</el-breadcrumb-item>
    </el-breadcrumb>

    <div id="container">
      <div id="content">
        <!-- ----------1.分类列表导航---------- -->
        <div id="cate_list">
          <div class="cate_item">
            <span class="cate_title">分类：</span>
            <span class="choice">
              <a href="javascript:;">
                <span class="cate_textFirst">全部</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">潮流数码</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">办公户外</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">智慧零售</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">企业服务</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">礼券专区</span>
              </a>
            </span>
          </div>

          <div class="cate_item">
            <span class="cate_title">品牌：</span>
            <span class="choice">
              <a href="javascript:;">
                <span class="cate_textFirst">不限</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">得力</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">洁丽雅</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">维达</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">公牛</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">罗技</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">漫步者</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">金士顿</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">闪迪</span>
              </a>
            </span>
          </div>

          <div class="cate_item">
            <span class="cate_title">积分：</span>
            <span class="choice">
              <a href="javascript:;">
                <span class="cate_textFirst">不限</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">0-1000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">1000-2000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">2000-3000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">3000-5000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">5000-10000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">10000-20000</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">20000以上</span>
              </a>
            </span>
            <span id="range">
              <input type="text" class="range_start" />
              <i class="el-icon-minus"></i>
              <input type="text" />
              <button>确定</button>
            </span>
          </div>

          <div class="cate_item">
            <span class="cate_title">支付方式：</span>
            <span class="last_choice">
              <a href="javascript:;">
                <span class="cate_textFirst">不限</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">积分</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">积分+现金</span>
              </a>
            </span>
          </div>
        </div>
        <div
          id="space"
          style="width:1200px;height:12px;background-color:#f5f5f5;margin-left: -40px;"
        ></div>
        <!-- ----------2.产品排序方式产品及列表---------- -->
        <div id="pBox">
          <div class="cate_item solid_borderBottom">
            <span class="cate_title">排序方式：</span>
            <span class="last_choice">
              <a href="javascript:;">
                <span class="cate_textFirst">默认排序</span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">
                  销量
                  <i class="el-icon-bottom"></i>
                </span>
              </a>

              <a href="javascript:;">
                <span class="cate_text">
                  人气
                  <i class="el-icon-bottom"></i>
                </span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">
                  最新
                  <i class="el-icon-bottom"></i>
                </span>
              </a>
              <a href="javascript:;">
                <span class="cate_text">
                  积分
                  <i class="el-icon-bottom"></i>
                </span>
              </a>
            </span>
            <span id="product_number">此系列共 658 个商品</span>
          </div>
          <div id="product_list">
            <el-row :gutter="16">
              <router-link to="/detail">
                <el-col :span="6" v-for="(item,i) of productItem" :key="i">
                  <div class="grid-content">
                    <img :src="item.image_path" />
                    <div class="product_text">
                      <p class="product_title">{{item.title}}</p>
                      <p class="credit">{{item.credit}}积分</p>
                      <p class="count">已兑换{{item.count}}个</p>
                    </div>
                  </div>
                </el-col>
              </router-link>
            </el-row>
          </div>
          <!-- 3.分页器 -->
          <div class="block solid_borderBottom">
            <el-pagination
              background
              @current-change="handleCurrentChange"
              :current-page="currentPage4"
              :page-size="100"
              layout="prev, pager, next, total,jumper"
              :total="1000"
            ></el-pagination>
            <el-button>确定</el-button>
            <!-- 分页器部分结构改写 -->
            <!-- <el-button
                plain
                icon="el-icon-arrow-left"
                id="prev"
                style="position:relative;left: -709px;"
              >上一页</el-button>
              <el-button plain id="next">
                下一页
                <i class="el-icon-arrow-right"></i>
              </el-button>
              <span class="el-pagination__total" style="font-size: 13px;">共 100 页，</span>
              <span class="el-pagination__jump" style="font-size: 13px;">
                到
                <div class="el-input el-pagination__editor is-in-pagination">
                  <input type="number" autocomplete="off" min="1" max="10" class="el-input__inner" />
                </div>页
            </span>-->
          </div>
        </div>

        <!-- ----------3.横向推进轮播图 ---------- -->
        <div id="carousel">
          <p id="browser">最近浏览</p>
          <div class="swiper-container">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <router-link to="/detail">
                  <img src="../../../../public/images/products/products_p1.png" />
                  <div class="product_text">
                    <p class="product_title">标题1</p>
                    <p class="credit">1积分</p>
                    <p class="count">已兑换1个</p>
                  </div>
                </router-link>
              </div>
              <div class="swiper-slide">
                <router-link to="/detail">
                  <img src="../../../../public/images/products/products_p1.png" />
                  <div class="product_text">
                    <p class="product_title">标题2</p>
                    <p class="credit">2积分</p>
                    <p class="count">已兑换2个</p>
                  </div>
                </router-link>
              </div>

              <div class="swiper-slide">
                <router-link to="/detail">
                  <img src="../../../../public/images/products/products_p1.png" />
                  <div class="product_text">
                    <p class="product_title">标题3</p>
                    <p class="credit">3积分</p>
                    <p class="count">已兑换3个</p>
                  </div>
                </router-link>
              </div>

              <div class="swiper-slide">
                <router-link to="/detail">
                  <img src="../../../../public/images/products/products_p1.png" />
                  <div class="product_text">
                    <p class="product_title">标题4</p>
                    <p class="credit">4积分</p>
                    <p class="count">已兑换4个</p>
                  </div>
                </router-link>
              </div>
            </div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>
  
<!-- 二.JS脚本 -->
<script>
import axios from 'axios'
export default {
  name: 'products',
  data() {
    return {
      // 用来存放列表页数据的数组
      productItem: [],
      // 分页初始化数据
      currentPage1: 5,
      currentPage2: 5,
      currentPage3: 5,
      currentPage4: 4
    }
  },
  mounted() {
    this.goodList()
    this.initCarousel()
  },

  methods: {
    // 产品列表页的方法：
    goodList() {
      // 绑定this的指向
      const self = this
      return this.axios
        .get('http://localhost:34975/products.json')
        .then(function(res) {
          console.log(res.data.products)
          // 把Json中获取到的数据赋值给数组productItem
          self.productItem = res.data.products

          // 循环出多条数据:
          var productItem = []
          for (var i = 0; i < 40; i++) {
            self.productItem[i] = res.data.products[0]
          }
        })
    },
    // 分页器的方法：
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
    },
    // 横向推进轮播图
    initCarousel() {
      var swiper = new Swiper('.swiper-container', {
        // 自动轮播
        // autoplay: true,
        slidesPerView: 4,
        spaceBetween: 16,
        hideOnClick: true,
        loop: true,
        loopFillGroupWithBlank: true,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      })
    }
  }
}
</script>

<!-- 三.CSS样式 -->
<style>
body {
  background-color: #f5f5f5 !important;
}
</style>

<style scoped>
/* 0.统一样式 */
body {
  width: 100%;
}
#main {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
#main #breadcrumb {
  padding-left: 10px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
#main #breadcrumb {
  font-size: 12px !important;
  margin-bottom: 20px;
}
#container {
  padding-top: 20px;
  background-color: #ffffff;
}
#content {
  margin: 10px 40px 41px 40px;
  padding-bottom: 41px;
}
/* 1.分类导航样式 */
#cate_list {
  background-color: #ffffff;
}
.cate_title {
  color: #999999;
  font-size: 14px;
}
.cate_text {
  color: #333333;
}
.cate_textFirst {
  color: #428bca !important;
}
.cate_item {
  border-bottom: 1px dotted #eeeeee;
  width: 1120px;
  padding: 20px 0px;
  font-size: 14px;
}
.cate_item a {
  padding-right: 29px;
}
.choice {
  margin-left: 42px;
}
.last_choice {
  margin-left: 14px;
}
#range {
  margin-left: 62px;
}
#range input {
  width: 70px;
  height: 30px;
  color: #999999;
  border-radius: 6px;
  border: 1px solid #eeeeee;
  background-color: #f8f8f8;
  text-align: center;
}
#range input:focus {
  outline: none;
}
#range .el-icon-minus:before {
  content: '\E6D8';
  width: 8px;
  height: 1px;
  color: #eeeeee;
  margin: 0 2px;
}
#range button {
  width: 70px;
  height: 30px;
  color: #6aaee8;
  background-color: #ffffff;
  border: 1px solid #6aaee8;
  border-radius: 6px;
  margin-left: 12px;
}
#range button:hover {
  border-color: #358fe9;
  color: #358fe9;
}
#range button:focus {
  outline: 0;
}

/* 2.产品列表样式 */
#pBox {
  background-color: #ffffff;
}
#pBox .solid_borderBottom {
  border-bottom: 1px solid #eeeeee;
  padding-bottom: 36px;
}
#product_number {
  font-size: 14px;
  color: #666666;
  float: right;
}
#product_list {
  margin: 31px 8px 36px 8px;
  width: 1104px;
}

.el-col {
  width: 264px;
  height: 396px;
}
#product_list img {
  width: 262px;
  height: 262px;
  border: 1px solid #eeeeee;
}

.product_text {
  font-size: 14px;
  text-align: center;
}
.product_title {
  color: #333333;
  font-weight: bold;
}
.credit {
  color: #ef4949;
  margin: 12px 0;
}
.credit:after {
  content: '';
  width: 120px;
  height: 1px;
  background-color: #eeeeee;
  position: absolute;
  margin-top: 33px;
  margin-left: -84px;
}
.count {
  color: #999999;
  padding-top: 12px;
}

/* 栅格布局样式 */
.el-row {
  margin-bottom: 20px;
  width: 1104px;
  margin-left: 0px !important;
  margin-right: 0px !important;
}
.row-bg {
  padding: 10px 0;
}
.grid-content {
  width: 264px;
  height: 396px;
  min-height: 36px;
}
.el-col-6 {
  width: 25% !important;
}
/* 分页器样式 */
.block {
  display: flex;
  justify-content: center;
}
/* 选中页码的颜色在页面设置好后代码中改无效 */
/* .el-pagination.is-background .el-pager li:not(.disabled).active {
  background-color: #428bca !important;
}
li.number.active {
  background-color: #428bca !important;
}
.el-pager li.active {
  background-color: #428bca !important;
} */
button.el-button.el-button--default {
  width: 70px !important;
  height: 28px !important;
  padding: 0 !important;
  margin-top: 2px;
}
#prev {
  /* position: relative;
  left: -709px; */
}

/* 去除按钮'上一页'与'下一页' 悬停及选中时的样式 */
/* .el-button.is-plain:focus,
.el-button.is-plain:hover {
  border-color: #dcdfe6;
  color: #606266;
} */

/* 3.轮播图样式 */
#browser {
  color: #333333;
  font-size: 16px;
  margin: 25px 1033px 8px 14px;
}

.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

.el-carousel__container {
  height: 375px !important;
}

/* swiper轮播图样式 */
.swiper-container {
  width: 100%;
  height: 100%;
}
.swiper-slide {
  text-align: center;
  font-size: 18px;
  background: #fff;
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
.swiper-slide.swiper-slide-active {
  /* margin-right: 0px !important;
  margin-left: 31px; */
}
#carousel img {
  width: 264px;
  height: 264px;
  border: 1px solid #eeeeee;
}
#carousel .product_text {
  position: relative;
  height: 75px;
}
.swiper-slide {
  /* margin-right: 0px !important; */
  width: 264px;
}
.swiper-button-prev,
.swiper-container-rtl .swiper-button-next {
  left: 2px;
  width: 20px;
  height: 80px;
  background-color: rgba(221, 214, 214, 0.6);
  top: 126px;
}
.swiper-button-next,
.swiper-container-rtl .swiper-button-prev {
  right: 2px;
  width: 20px;
  height: 80px;
  background-color: rgba(221, 214, 214, 0.6);
  top: 126px;
}
.swiper-wrapper {
  width: 1104px;
  height: 396px;
}
</style>

