<!-- 个人中心--更换手机号页面 -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <div id="container">
      <!-- 1.1 面包屑导航 -->
      <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/personal' }">个人中心</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/safety' }">账号安全</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/changePhone' }">更换手机号</el-breadcrumb-item>
      </el-breadcrumb>
      <div id="content">
        <!-- 1.2 侧边栏子组件 -->
        <my-sidebar></my-sidebar>
        <!-- 1.3 中间内容:用户基本信息 -->
        <div id="middle">
          <div class="tHead">
            <span class="title ml20">更换手机号</span>
          </div>
          <div id="text">
            <!-- active往里传值即可显示步骤 -->
            <el-steps :space="180" :active="currentStep" :color="customColor">
              <el-step title="身份验证"></el-step>
              <el-step title="更换手机号"></el-step>
              <el-step title="完成"></el-step>
            </el-steps>
            <div id="check">
              <p>已绑定的手机号：183****6598</p>
              <div id="inputGroup">
                <el-input v-model="testCode" placeholder="请输入短信验证码"></el-input>
                <a href="javascript:;">获取验证码</a>
              </div>
              <el-button type="info">下一步</el-button>
            </div>
          </div>
          <div id="tips">
            <p class="ml16 subtitle">温馨提示</p>
            <ul class="ml16 desc">
              <li>• 为保障您的账号安全，变更重要信息需要身份验证；</li>
              <li>• 若有疑问请联系在客服；</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
// 引入侧边导航栏子组件
import MySidebar from '../../../components/Sidebar.vue'

export default {
  data() {
    return {
      // 步骤进度条初始化
      currentStep: 2,
      customColor: '#5FA3DE',
      // 输入验证码初始化
      testCode: ''
    }
  },
  components: {
    // 侧边导航栏子组件(在父组件中用components属性包裹所有子组件)
    MySidebar
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 3.0 统一样式 */
* {
  margin: 0;
  padding: 0;
}
body {
  width: 100%;
  background-color: #ffffff !important;
}
#main {
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #eeeeee;
  height: 789px;
}
#container {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
#content {
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
}
/* 3.1 面包屑导航样式 */
#container #breadcrumb {
  padding-left: 10px;
  font-size: 12px !important;
  margin-bottom: 20px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
/* 3.3 中间内容样式： */
#middle {
  width: 960px;
}
/* 表头样式 */
.tHead {
  width: 960px;
  height: 48px;
  line-height: 48px;
  display: flex;
  justify-content: space-between;
  background-color: #f5f5f5;
}
.title {
  font-size: 16px;
  color: #666666;
  margin-bottom: 19px;
}
.ml20 {
  margin-left: 20px;
}
#text {
  width: 958px;
  height: 358px;
  border: 1px solid #eeeeee;
  margin-bottom: 16px;
  font-size: 14px;
}
#tips {
  width: 960px;
  height: 110px;
  background-color: #f5f5f5;
  color: #999999;
}
.ml16 {
  margin-left: 16px;
}
ul.ml16.desc {
  margin-top: 19px;
}
.subtitle {
  font-size: 16px;
  padding-top: 20px;
}
.desc {
  font-size: 14px;
}
::v-deep .el-step__title.is-finish {
  color: #333333 !important;
}
::v-deep .el-step__head.is-finish {
  color: #5fa3de !important;
  border-color: #5fa3de !important;
}

::v-deep .el-step__title.is-process {
  color: #999999 !important;
}
::v-deep .el-step__icon.is-text {
  border-color: #dddddd !important;
}
.el-steps.el-steps--horizontal {
  margin-left: 290px;
  padding-top: 60px;
}
#text {
  font-size: 16px;
  color: #333333;
}
div#check {
  text-align: center;
  margin-top: 60px;
}
#inputGroup {
  width: 240px !important;
  height: 40px !important;
  margin-top: 16px !important;
  margin: 0 auto;
  border: 1px solid #eeeeee;
  border-radius: 4px;
}
.el-input {
  width: 150px;
}
::v-deep #check .el-input__inner {
  border: none !important;
  padding-left: 10px;
}
#inputGroup a {
  font-size: 14px;
  color: #428bca;
}
#check a:before {
  content: '';
  width: 1px;
  height: 30px;
  position: absolute;
  background-color: #eeeeee;
  margin-left: -12px;
  margin-top: 5px;
}
#check button {
  margin-top: 30px;
  width: 90px;
  height: 40px;
  font-size: 16px;
  color: #999999;
  background-color: #f5f5f5;
  border: none;
}
</style>