<!-- <h1>个人中心页面</h1> -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <div id="container">
      <!-- 1.1 面包屑导航 -->
      <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>个人中心</el-breadcrumb-item>
      </el-breadcrumb>

      <div id="content">
        <!-- 1.2 左侧导航栏 -->
        <el-row class="tac">
          <el-col :span="4">
            <el-menu
              default-active="2"
              class="el-menu-vertical-demo"
              @open="handleOpen"
              @close="handleClose"
              text-color="#333333"
              active-text-color="#428BCA"
            >
              <el-submenu index="1">
                <template slot="title">
                  <span>账号管理</span>
                </template>
                <el-menu-item-group>
                  <router-link to="./personal">
                    <el-menu-item index="1-1">个人中心</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-2">消息通知</el-menu-item>
                  </router-link>
                  <router-link to="./account">
                    <el-menu-item index="1-3">账号信息</el-menu-item>
                  </router-link>
                  <router-link to="./address">
                    <el-menu-item index="1-4">地址管理</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-5">账号安全</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-6">我的积分</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-7">我的卡券</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-8">我的收藏</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-9">我的足迹</el-menu-item>
                  </router-link>
                </el-menu-item-group>
              </el-submenu>
              <el-submenu index="2">
                <template slot="title">
                  <span>交易管理</span>
                </template>
                <el-menu-item-group>
                  <router-link to="./personal">
                    <el-menu-item index="1-10">订单管理</el-menu-item>
                  </router-link>
                  <router-link to="./personal">
                    <el-menu-item index="1-11">退款管理</el-menu-item>
                  </router-link>
                </el-menu-item-group>
              </el-submenu>
            </el-menu>
          </el-col>
        </el-row>

        <!-- 1.3 中间内容:用户信息+订单列表+收藏 -->
        <div id="middle">
          <!-- 1.3.1 中间内容--用户信息 -->
          <div class="user">
            <img src="../../../../public/images/personal_center/personal/user.png" />
            <div id="text">
              <div class="title">用户名</div>
              <div id="myMessage">
                <span class="credit">
                  我的积分：
                  <span>1000</span>
                </span>
                <span class="coupon">
                  卡券：
                  <span>4</span>
                  <span>张</span>
                </span>
              </div>
            </div>
            <div id="btn">
              <el-button type="primary">赚积分</el-button>
              <el-button type="primary" plain>花积分</el-button>
            </div>
          </div>
          <!-- 1.3.2 中间内容--订单列表-->
          <div id="order">
            <div class="tHead">
              <router-link to="/personal">
                <span class="title ml20">我的订单</span>
              </router-link>
              <router-link to="/personal">
                <span class="title mr20">查看全部订单</span>
              </router-link>
            </div>

            <el-table :data="orderData" border style="width: 100%">
              <el-table-column prop="pictures" label="订单信息">
                <template slot-scope="scope">
                  <p>订单号：{{ scope.row.orderNo }}</p>
                  <img
                    style="width:80px;height:80px;"
                    src="../../../../public/images/personal_center/personal/products_p1.png"
                    class="head_pic"
                  />
                  <img
                    style="width:80px;height:80px;"
                    src="../../../../public/images/personal_center/personal/products_p2.png"
                    class="head_pic"
                  />
                  <img
                    style="width:80px;height:80px;"
                    src="../../../../public/images/personal_center/personal/products_p3.png"
                    class="head_pic"
                  />
                  <!-- <img v-for="item in scope.row.pictures" :src="item.pictures" class="head_pic" /> -->
                  <span>共{{ scope.row.count }}件商品</span>
                </template>
              </el-table-column>

              <el-table-column label="价格" width="200">
                <template slot-scope="scope">
                  <span style="margin-left: 10px">{{ scope.row.price }}</span>
                </template>
              </el-table-column>

              <el-table-column label="操作" width="200">
                <template slot-scope="scope">
                  <el-button size="mini" type="warning">付款￥100</el-button>
                  <br />
                  <el-button size="mini" @click="handleCheck(scope.$index, scope.row)">查看详情</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>

          <!-- 1.3.3 中间内容--收藏 -->
          <div id="collect">
            <div class="tHead">
              <router-link to="/personal">
                <span class="title ml20">我的收藏</span>
              </router-link>
            </div>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content borderProduct">
                  <router-link to="/Detail.vue">
                    <img src="../../../../public/images/products/products_p1.png" />
                    <div class="product_text">
                      <p class="product_title">标题1</p>
                      <p class="credit">1积分</p>
                    </div>
                  </router-link>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content borderProduct">
                  <router-link to="/Detail.vue">
                    <img src="../../../../public/images/products/products_p1.png" />
                    <div class="product_text">
                      <p class="product_title">标题2</p>
                      <p class="credit">2积分</p>
                    </div>
                  </router-link>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content borderProduct">
                  <router-link to="/Detail.vue">
                    <img src="../../../../public/images/products/products_p1.png" />
                    <div class="product_text">
                      <p class="product_title">标题3</p>
                      <p class="credit">3积分</p>
                    </div>
                  </router-link>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content borderProduct">
                  <router-link to="/Detail.vue">
                    <img src="../../../../public/images/products/products_p1.png" />
                    <div class="product_text">
                      <p class="product_title">标题4</p>
                      <p class="credit">4积分</p>
                    </div>
                  </router-link>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
export default {
  data() {
    return {
      // 2.3.2 中间内容--订单列表数据
      orderData: [
        {
          orderNo: '1023456781',
          pictures:
            '../../../../public/images/personal_center/personal/user.png',
          price: '100积分',
          count: 1
        },
        {
          orderNo: '2023456782',
          price: '200积分+￥20',
          count: 2
        },
        {
          orderNo: '3023456783',
          price: '300积分',
          count: 3
        },
        {
          orderNo: '4023456784',
          price: '400积分+￥40',
          count: 4
        }
      ]
    }
  },
  methods: {
    // 2.2 左侧导航栏的方法
    handleOpen(key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath)
    },
    // 2.3.3 中间内容--订单列表的方法
    handleCheck(index, row) {
      console.log(index, row)
    }
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 3.0 统一样式 */
* {
  margin: 0;
  padding: 0;
}
body {
  width: 100%;
  background-color: #ffffff !important;
}
#main {
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #eeeeee;
}
#container {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
#content {
  display: flex;
  justify-content: space-between;
}
/* 3.1 面包屑导航样式 */
#container #breadcrumb {
  padding-left: 10px;
  font-size: 12px !important;
  margin-bottom: 20px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
/* 3.2 左侧导航栏样式 */
.el-col.el-col-4 {
  border: 1px solid #eeeeee;
  width: 224px;
}
.el-submenu__title * {
  font-size: 16px;
  font-weight: bold;
}
::v-deep .el-submenu__title {
  text-align: center;
}
li.el-menu-item {
  text-align: center;
  color: #666666 !important;
}
/* 3.3 中间内容样式：用户信息+订单列表+收藏 */
#middle {
  width: 960px;
}
/* 3.3.1 中间内容样式--用户信息 */
#middle .user {
  width: 960px;
  height: 140px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  border: 1px solid #eeeeee;
}
.user img {
  width: 78px;
  height: 78px;
  margin-left: 20px;
}
div#text {
  margin-left: 20px;
}
.title {
  font-size: 16px;
  color: #333333;
  margin-bottom: 19px;
}
#myMessage {
  font-size: 14px;
  color: #666666;
}
span.credit {
  margin-right: 30px;
}
.credit > span {
  color: #428bca;
  font-weight: bold;
  font-size: 16px;
}
.coupon span:first-child {
  color: #428bca;
  font-weight: bold;
  font-size: 16px;
  margin-right: 3px;
}
div#btn {
  margin-left: 427px;
}
.el-button {
  width: 90px !important;
}
#btn button:first-child {
  background-color: #428bca;
  font-size: 16px;
}
#btn button:last-child {
  background-color: #ffffff;
  color: #428bca;
  font-size: 16px;
}
/* 3.3.2 中间内容样式--订单列表 */
#order {
  width: 960px;
}
.tHead {
  width: 960px;
  height: 48px;
  line-height: 48px;
  display: flex;
  justify-content: space-between;
  background-color: #f5f5f5;
}
#order .title {
  color: #666666;
}
.ml20 {
  margin-left: 20px;
}
.mr20 {
  margin-right: 20px;
}
td.el-table_1_column_1 {
  position: relative;
}
td.el-table_1_column_1 span {
  position: absolute;
  top: 50%;
  left: 80%;
}
.el-button--warning {
  background-color: #f49447 !important;
  border-color: #f49447 !important;
  font-size: 14px;
  margin-bottom: 12px;
}
.cell {
  margin-left: 10px;
}
::v-deep .el-table .cell,
.el-table th div,
.el-table--border td:first-child .cell,
.el-table--border th:first-child .cell {
  padding-left: 20px !important;
}
img.head_pic {
  margin-top: 20px;
  margin-right: 16px;
}
::v-deep .el-table_1_column_2 .cell {
  text-align: center !important;
  padding-right: 20px !important;
}
::v-deep .el-table_1_column_3 .cell {
  text-align: center !important;
  padding-right: 20px !important;
}
/* 3.3.3 中间内容样式--收藏 */
#collect {
  width: 960px;
  height: 400px;
  border: 1px solid #eeeeee;
  margin-top: 16px;
  margin-bottom: 30px;
}
/* 栅格布局的样式 */
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
  width: 220px;
  height: 290px;
  text-align: center;
  margin-top: 32px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
#collect .el-row {
  padding-left: 16px;
  padding-right: 16px;
}
#collect img {
  width: 218px;
  height: 218px;
}
.borderProduct {
  border: 1px solid #eeeeee;
}
.product_text {
  font-size: 14px;
  margin-top: 8px;
  margin-bottom: 15px;
}
.product_title {
  color: #333333;
  margin-bottom: 13px;
  font-weight: bold;
}
.credit {
  color: #ef4949;
}
</style>