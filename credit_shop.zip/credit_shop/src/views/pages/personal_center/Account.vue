<!-- 一.HTML代码 -->
<!-- <h1>账号信息页面</h1> -->
<template>
  <main id="main">
    <div id="container">
      <!-- 1.1 面包屑导航 -->
      <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/personal' }">个人中心</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/account' }">账号信息</el-breadcrumb-item>
      </el-breadcrumb>
      <div id="content">
        <!-- 1.2 侧边栏子组件 -->
        <my-sidebar></my-sidebar>
        <!-- 1.3 中间内容:用户基本信息 -->
        <div id="middle">
          <div class="tHead">
            <span class="title ml20">基本信息</span>
          </div>
          <div id="list">

            <!-- 上传头像并预览 -->
            <div class="list_item">
              <span class="subtitle">用户头像：</span>
              <el-upload
                class="avatar-uploader"
                action="https://jsonplaceholder.typicode.com/posts/"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="imageUrl" :src="imageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </div>
            

            <div class="list_item">
              <span class="subtitle">用户账号：</span>
              <span class="desc">{{userObject.account}}</span>
            </div>
            <div class="list_item">
              <span class="subtitle">性别：</span>
              <span class="desc" id="sex">
                <el-radio v-model="userObject.sex" label="1">男</el-radio>
                <el-radio v-model="userObject.sex" label="0">女</el-radio>
              </span>
            </div>
            <div class="list_item">
              <span class="subtitle">手机号码：</span>
              <span class="desc">{{userObject.phone}}</span>
              <span class="desc">
                <router-link to="./changePhone" id="phone">更换手机号</router-link>
              </span>
            </div>
            <div class="list_item">
              <span class="subtitle">出生日期：</span>
              <span class="desc">
                <div class="block">
                  <el-date-picker v-model="userObject.birthday" type="date" placeholder="选择日期"></el-date-picker>
                </div>
              </span>
            </div>

            <div class="list_item">
              <span class="desc">
                <el-button type="primary" id="save" @click='toSave'>保存</el-button>
              </span>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
// 引入侧边导航栏子组件
import MySidebar from '../../../components/Sidebar.vue';
// 引入axios
import axios from 'axios';
import qs from 'qs';
import { stringify } from 'querystring';


export default {
  // 显示上传图片的脚本代码

  data() {
    // 手机号中间4位数隐藏
    var phone='15155158372';
    var hidePhone=phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');

    return {
      // 上传头像初始化
      imageUrl: require('../../../../public/images/icon/avatar.png'),
      // 用来用户信息的整个对象
      userObject:{
        avatar:'touxiang', //头像的图片需先传到文件服务器 再从后端拿到图片地址 才能上传保存
        account:'vgi21532133',
        sex:'',
        phone:hidePhone,
        birthday: '',
      }
    }
  },
  components: {
    // 侧边导航栏子组件(在父组件中用components属性包裹所有子组件)
    MySidebar
  },
  methods:{

    // 上传头像的方法：
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!');
      }
      return isJPG && isLt2M;
  },

    // 保存整个用户账户数据的方法：
    toSave(){
      let data = qs.stringify({ //将对象转回成查询字符串
        object: JSON.stringify(this.userObject)
      });
      axios.post("api/api/addUser", data).then((res) => {
        //逻辑代码
        if(res.data.code==200){
          alert('保存成功');
          console.log(res);
        }else{
          alert("保存失败！");
          console.log(res);
        }
      });

      
    }
  }
}
</script>

<!-- 三.CSS样式 -->
<style>
body {
  width: 100%;
  /* background-color: #ffffff !important; */
}
</style>
<style scoped>
/* 3.0 统一样式 */
* {
  margin: 0;
  padding: 0;
}
#main {
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #eeeeee;
  height: 789px;
}
#container {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
#content {
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
}
/* 3.1 面包屑导航样式 */
#container #breadcrumb {
  padding-left: 10px;
  font-size: 12px !important;
  margin-bottom: 20px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
/* 3.3 中间内容样式：用户基本信息 */
#middle {
  width: 960px;
  height: 471px;
  border: 1px solid #eeeeee;
}
/* 表头样式 */
.tHead {
  width: 960px;
  height: 48px;
  line-height: 48px;
  display: flex;
  justify-content: space-between;
  background-color: #f5f5f5;
}
.title {
  font-size: 16px;
  color: #666666;
  margin-bottom: 19px;
}
.ml20 {
  margin-left: 20px;
}
#list {
  margin-left: 32px;
  font-size: 14px;
}
.list_item {
  margin-top: 30px;
  margin-bottom: 30px;
  display: flex;
  align-items: center
}

.subtitle {
  color: #666666;
}
.desc {
  color: #333333;
  margin-left: 22px;
}
#avatar {
  width: 167px;
  height: 70px;
  line-height: 70px;
  background: url(../../../../public/images/icon/avatar.png) no-repeat right
    center;
  background-size: 70px 70px;
}
#avatar img {
  width: 18px;
  height: 15px;
  margin-bottom: -30px;
  margin-left: 76px;
}

input[type='file'] {
  position: relative;
  top: -67px;
  left: 97px;
  opacity: 0;
}
#borderStyle {
  width: 70px;
  height: 70px;
  border: 1px dashed #999999;
  float: right;
  margin-top: -71px;
}
#sex {
  margin-left: 50px;
}
::v-deep .el-radio__label {
  color: #333333 !important;
}
#phone {
  color: #428bca;
  font-size: 14px;
}
.block {
  display: inline-block;
}
.el-button--primary {
  background-color: #428bca !important;
}
#save {
  margin-left: -22px;
  width: 96px;
}

/* element上传图片的样式 */
  ::v-deep .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    width:72px;
    height:72px;
    margin-left: 16px;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 72px !important;
    height: 72px !important;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 72px;
    height: 72px;
    display: block;
  }
</style>