<!-- 个人中心--更换手机号页面 -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <div id="container">
      <!-- 1.1 面包屑导航 -->
      <el-breadcrumb separator-class="el-icon-arrow-right" id="breadcrumb">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/Personal.vue' }">个人中心</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/Account.vue' }">账号信息</el-breadcrumb-item>
      </el-breadcrumb>
      <div id="content">
        <!-- 1.2 侧边栏子组件 -->
        <my-sidebar></my-sidebar>
        <!-- 1.3 中间内容: -->
        <div id="middle">
          <div class="tHead">
            <span class="title ml20">收货地址</span>
          </div>
          <div id="text">
            <!-- 1.3.1 中间内容:地址列表 -->
            <ul id="list_addr">
              <li class="item">
                <div class="info">
                  <span class="name">张三</span>
                  <span class="default">默认地址</span>
                  <p class="phone">183****0369</p>
                  <p class="addr">
                    广东省深圳市福田区凉凉路12号凉凉
                    小区2栋503号
                  </p>
                  <div class="operate">
                    <a href="javascript:;" class="edit">编辑</a>
                    <a href="javascript:;" class="del">删除</a>
                  </div>
                </div>
              </li>
              <li class="item">
                <div class="info">
                  <span class="name">张三</span>
                  <span class="setDefault">设为默认地址</span>
                  <p class="phone">183****0369</p>
                  <p class="addr">
                    广东省深圳市福田区凉凉路12号凉凉
                    小区2栋503号
                  </p>
                  <div class="operate">
                    <a href="javascript:;" class="edit">编辑</a>
                    <a href="javascript:;" class="del">删除</a>
                  </div>
                </div>
              </li>
              <li class="item">
                <div class="info">
                  <span class="name">张三</span>
                  <span class="setDefault">设为默认地址</span>
                  <p class="phone">183****0369</p>
                  <p class="addr">
                    广东省深圳市福田区凉凉路12号凉凉
                    小区2栋503号
                  </p>
                  <div class="operate">
                    <a href="javascript:;" class="edit">编辑</a>
                    <a href="javascript:;" class="del">删除</a>
                  </div>
                </div>
              </li>
              <li class="item">
                <div class="info">
                  <span class="name">张三</span>
                  <span class="setDefault">设为默认地址</span>
                  <p class="phone">183****0369</p>
                  <p class="addr">
                    广东省深圳市福田区凉凉路12号凉凉
                    小区2栋503号
                  </p>
                  <div class="operate">
                    <a href="javascript:;" class="edit">编辑</a>
                    <a href="javascript:;" class="del">删除</a>
                  </div>
                </div>
              </li>
              <li class="item">
                <div class="info">
                  <span class="name">张三</span>
                  <span class="setDefault">设为默认地址</span>
                  <p class="phone">183****0369</p>
                  <p class="addr">
                    广东省深圳市福田区凉凉路12号凉凉
                    小区2栋503号
                  </p>
                  <div class="operate">
                    <a href="javascript:;" class="edit">编辑</a>
                    <a href="javascript:;" class="del">删除</a>
                  </div>
                </div>
              </li>
            </ul>
            <!-- 1.3.2 中间内容:分割线 -->
            <div id="borderStyle"></div>
            <!-- 1.3.3 中间内容:新增地址 -->
            <div id="newAddr">
              <span class="title">新增收货地址</span>
              <div id="list_new">
                <div class="new_item">
                  <span class="must">*</span>
                  <span class="subtitle">所在地址</span>
                  <area-cascader
                    type="all"
                    v-model="selected"
                    :level="1"
                    :data="pcaa"
                    placeholder="请选择省/市/区/街道"
                  ></area-cascader>
                  <!-- <i class="el-icon-arrow-down"></i> -->
                </div>

                <div class="new_item">
                  <span class="must">*</span>
                  <span class="subtitle">详细地址</span>
                  <el-input
                    type="textarea"
                    :rows="2"
                    placeholder="请输入详细地址、街道、门牌号等"
                    v-model="textarea"
                  ></el-input>
                </div>
                <div class="new_item">
                  <span class="must">*</span>
                  <span class="subtitle" id="host">收货人姓名</span>
                  <el-input class="size" v-model="input" placeholder="建议不使用昵称、X先生，X小姐等，使用真实姓名"></el-input>
                </div>
                <div class="new_item">
                  <span class="must">*</span>
                  <span class="subtitle">手机号码</span>
                  <el-input class="size" v-model="input" placeholder="手机号码必填"></el-input>
                </div>
                <div class="new_item" id="tel">
                  <span class="subtitle ml17">电话号码</span>
                  <el-input v-model="input" placeholder="区号"></el-input>
                  <el-input v-model="input" id="tel_middle" placeholder="电话号码"></el-input>
                  <el-input v-model="input" placeholder="分机号"></el-input>
                </div>
                <div class="new_item">
                  <span class="subtitle ml17">邮箱</span>
                  <el-input class="size" v-model="input" placeholder="接收订单提醒邮件，便于您及时了解订单动态"></el-input>
                </div>
                <div class="new_item">
                  <span class="lineStyle left"></span>
                  <span class="lineStyle right"></span>
                </div>
                <el-button type="primary">确定</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>



<!-- 二.JS脚本 -->
<script>
// 引入侧边导航栏子组件
import MySidebar from '../../../components/Sidebar.vue'
// 根据需要按需引入数据--地区联动
import { pca, pcaa } from 'area-data'

export default {
  data() {
    return {
      selected: [],
      pcaa: pcaa, //最多省市区三级，结合:level='2'选择，0省、1省市、2省市区
      // 详细地址的文本域初始化
      textarea: '',
      // 收货人姓名初始化
      input: ''
    }
  },
  components: {
    // 侧边导航栏子组件(在父组件中用components属性包裹所有子组件)
    MySidebar
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 3.0 统一样式 */
* {
  margin: 0;
  padding: 0;
}
body {
  width: 100%;
  background-color: #ffffff !important;
}
#main {
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #eeeeee;
}
#container {
  width: 1200px;
  margin: 0 auto;
  padding-top: 20px;
}
#content {
  display: flex;
  justify-content: space-between;
  /* 待删除背景色 */
  /* background-color: rgb(216, 209, 209); */
}
/* 3.1 面包屑导航样式 */
#container #breadcrumb {
  padding-left: 10px;
  font-size: 12px !important;
  margin-bottom: 20px;
}
::v-deep #breadcrumb .el-icon-arrow-right:before {
  margin: 0 -4px !important;
  color: #666666;
}
/* 3.3 中间内容样式：用户基本信息 */
#middle {
  width: 960px;
  /* 待删除背景色 */
  /* background-color: rgb(173, 169, 169); */
}
/* 表头样式 */
.tHead {
  width: 960px;
  height: 48px;
  line-height: 48px;
  display: flex;
  justify-content: space-between;
  background-color: #f5f5f5;
}
.title {
  font-size: 16px;
  color: #666666;
  margin-bottom: 19px;
}
.ml20 {
  margin-left: 20px;
}
#text {
  border: 1px solid #eeeeee;
  width: 960px;
  height: 927px;
}
#list_addr {
  width: 864px;
  height: 320px;
  margin: 0 auto;
  margin-top: 20px;
}
.item {
  width: 272px;
  height: 150px;
  border: 1px solid #eeeeee;
  float: left;
  margin-left: 7px;
  margin-right: 7px;
  margin-bottom: 20px;
}
.info {
  width: 238px;
  height: 91px;
  margin: 0 auto;
  margin-top: 20px;
}
.info {
  font-size: 14px;
  color: #999999;
}
.name {
  font-size: 16px;
  color: #333333;
}
.setDefault {
  float: right;
  color: #666666;
}
.default {
  float: right;
  color: #fd3d3d !important;
}
p.phone {
  margin-top: 12px;
  margin-bottom: 22px;
}
#borderStyle {
  width: 920px;
  border: 0.5px dashed #eeeeee;
  margin: 0 auto;
  margin-top: 30px;
}
.operate {
  margin-bottom: 10px;
  float: right;
  font-size: 14px;
  margin-top: -6px;
}
.operate a {
  color: #666666;
}
a.edit {
  margin-right: 20px;
}
a.edit:after {
  content: '';
  position: absolute;
  width: 1px;
  height: 10px;
  background: #cccccc;
  margin-top: 5px;
  margin-left: 10px;
}
/* 3.3.3 中间内容样式:新增地址 */
#newAddr {
  width: 580px;
  height: 495px;
  margin-top: 29px;
  margin-left: 20px;
  /* 待删除背景色 */
  /* background-color: grey; */
}
#list_new {
  width: 552px;
  height: 460px;
  margin-top: 19px;
  margin-left: 28px;
  /* 待删除背景色 */
  /* background-color: rgb(223, 215, 215); */
}
.new_item {
  display: flex;
  font-size: 14px;
  margin-bottom: 16px;
  justify-content: space-between;
}
.must {
  color: #fd3d3d;
  /* margin-right: 3px; */
  line-height: 40px;
}
.subtitle {
  color: #666666;
  margin-right: 13px;
  height: 40px;
  line-height: 40px;
}
::v-deep .area-select.large {
  width: 450px !important;
  height: 40px !important;
}
::v-deep .cascader-menu-list-wrap {
  width: 445px !important;
}
::v-deep .area-select .area-select-icon {
  /* border: 0; */
}
.el-icon-arrow-down:before {
  /* position: relative;
  left: -27px;
  line-height: 40px; */
}
::v-deep span.area-selected-trigger {
  font-size: 14px;
  font-family: Microsoft YaHei;
  color: #cccccc;
}
.el-textarea {
  width: 450px;
  height: 100px;
}
::v-deep textarea.el-textarea__inner {
  height: 100px;
}
.size {
  width: 450px;
  height: 40px;
}
span#host {
  margin-left: 12px;
}
.ml17 {
  margin-left: 17px;
}
::v-deep #tel input {
  width: 90px;
  height: 40px;
}
#tel .el-input {
  width: 16.5%;
  position: relative;
  left: -48px;
}
::v-deep #tel_middle {
  width: 160px !important;
  height: 40px;
  margin-left: -34px;
}

#list_new button {
  margin-left: 102px;
  margin-top: 4px;
  width: 100px;
  height: 40px;
  background-color: #428bca;
}
.lineStyle {
  width: 10px;
  height: 1px;
  background: #cccccc;
  margin-top: -92px;
}
.left {
  margin-left: 202px;
}
.right {
  margin-right: 150px;
}
</style>