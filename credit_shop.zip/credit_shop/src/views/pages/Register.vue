<!-- <h1>注册页面</h1> -->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <div id="container">
      <!-- 1.1 右侧内容区域 -->
      <div id="content">
        <!-- 1.1.1 右侧内容区域：LOGO -->
        <div class='login_logo'>
          <img src="../../../public/images/register/logo_login.png">
        </div> 
        <!-- 1.1.2 右侧内容区域：form表单 -->
        <div class='login_form'>
          <div class="head">
            <router-link to='./register' class='active'>注册账号</router-link>
          </div>
          <div class="text">
            <div id="register">
              <div class="form-group">
                <img src="../../../public/images/register/user.png">
                <el-input
                  placeholder="请输入用户名"
                  v-model="uname">
                </el-input>
                <div class="help-block">请输入正确的用户名</div>
              </div>
              <div class="form-group">
                <img src="../../../public/images/register/phone.png">
                <el-input
                  placeholder="请输入手机号"
                  v-model="phone">
                </el-input>
                <div class="help-block">请输入正确的手机号</div>
              </div>
              <div class="form-group">
                <img src="../../../public/images/register/verify.png">
                <el-input
                  placeholder="请输入短信验证码"
                  v-model="phone">
                </el-input>
                <el-button type="primary">发送验证码</el-button>
                <div class="help-block">请输入正确的验证码</div>
              </div>
              <div class="form-group">
                <img src="../../../public/images/register/key.png">
                <el-input
                  placeholder="请输入密码"
                  v-model="phone">
                </el-input>
                <div class="help-block">请输入正确的密码</div>
              </div>
              <div class="form-group">
                <img src="../../../public/images/register/key.png">
                <el-input
                  placeholder="请再次输入密码"
                  v-model="phone">
                </el-input>
                <div class="help-block">两次密码输入不同</div>
              </div>
              <router-link to='./login' id="toLogin">已有账号，立即登录</router-link>
              <el-button type="primary" id='toRegister'>注册</el-button>
            </div>
            <div id="third_login">
              <fieldset class="field-title text-center">
                <legend class="text-center">使用第三方账号登录</legend>
              </fieldset>
              <div class="third_group">
                <router-link to='./register' id='qq'>
                  <img src="../../../public/images/register/qq.png">
                </router-link>
                <router-link to='./register' id='vx'>
                  <img src="../../../public/images/register/vx.png">
                </router-link>
              </div>
            </div>
          </div>
        </div> 
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
  export default{
    data(){
      return{
        // 初始化
        uname:'',
        phone:'',
      }
    },
  }
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 3.0 统一样式 */
* {
  margin: 0;
  padding: 0;
}
body {
  width: 100%;
  background-color: #ffffff !important;
}
#main {
  width: 100%;
  height: 923px;
  background-image:url(../../../public/images/register/bg_login.png);
}
#container {
  width:1200px;
  margin:0 auto;
}
/* 3.1 内容区域样式*/
#content{
  width:500px;
  height:auto;
  display:block;
  text-align:center;
  float:right;
  margin:50px 0;
}
/* 3.1.2 右侧内容区域：form表单  */
.login_form{
  margin-top:35px;
  padding:0 85px 25px;
  background-color:#fff;
  border-radius:5px;
  text-align:center;
}
.login_form .head{
  border-bottom:1px solid #e7e6eb;
  margin:30px -85px;
  text-align:center;
}
.login_form .head .active{
  color: #428bca;
  display:inline-block;
  text-align:center;
  padding:20px 0;
  position:relative;
  margin:0 15px;
  font-size:14px;
}
a.active:after{
  content:'';
  width:100%;
  height:2px;
  background-color: #428bca;
  position:absolute;
  left:0;
  bottom:-1px;
}
.help-block {
  margin-top: 2px;
  margin-bottom: 5px;
  font-size: 10px;
  text-align: left;
  min-height: 16px;
  color: #a94442;
}

.el-input {
  width: 100%;
  vertical-align:middle
}
.form-group img {
  width: 15px;
  height: 15px;
  float: left;
  z-index: 100;
  position: relative;
  top: 28px;
  left: 10px;
}
::v-deep .el-input__inner {
  padding: 0 30px !important;
}
.form-group .el-button--primary {
  float: right;
  z-index: 200;
  position: relative;
  top: -40px;
  background-color: #A1C5E5;
  border-color: transparent;
  width: 95px;
  padding: 12px 10px;
}
.form-group .el-button {
  border-radius: 0 4px 4px 0;
}
#toLogin{
  color: #428bca;
  font-size:14px;
  float: right;
}
#toRegister{
  background-color:#3472A7;
  width:330px;
  height:40px;
  margin-top: 10px;
}
#third_login .field-title {
  margin-top: 38px;
  margin-bottom: 10px;
  padding: 0 5.5em;
  border: 0;
  border-top: 1px solid #e7e6eb!important;
  text-align: center;
}
#third_login legend {
  width: auto;
  padding: 0 10px;
  border: 0;
  font-size: 14px;
  color: #666;
}
.third_group a {
  margin-right: 10px;
  display: inline-block;
  width:40px;
  height:40px;
  background-color:rgb(170, 168, 168);
  border-radius:50%;
  line-height: 50px;
}
.third_group img{
  width:20px;
  height:20px;
}
.third_group a#qq:hover {
  background-color:#4CAFE9;
}
.third_group a#vx:hover {
  background-color:#2AA146;
}

</style>