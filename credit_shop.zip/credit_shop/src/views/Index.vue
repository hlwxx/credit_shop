<!-- <h1>这里是首页</h1>-->
<!-- 一.HTML代码 -->
<template>
  <main id="main">
    <!-- 0.轮播图子组件 -->
    <carousel></carousel>
    <div id="container">
      <!-- -------------------楼层一：精选爆款  id='f1'----------------- -->
      <div id="f1">
        <div class="slogan">
          <span class="big_slogan">精选爆款</span>
          <span class="small_slogan">精心挑选，想不到的惊喜</span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content" id="bgc1">
              <div class="content">
                <div class="text">
                  <p class="title">标题1</p>
                  <p class="subtitle">副标题1</p>
                  <a href="javascript:;">
                    查看详情
                    <img src="../../public/images/img_index/img_f1/arrow_right.png" />
                  </a>
                </div>
                <img src="../../public/images/img_index/img_f1/f1_p1.png" />
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content" id="bgc2">
              <div class="content">
                <div class="text">
                  <p class="title">标题1</p>
                  <p class="subtitle">副标题1</p>
                  <a href="javascript:;">
                    查看详情
                    <img src="../../public/images/img_index/img_f1/arrow_right.png" />
                  </a>
                </div>
                <img src="../../public/images/img_index/img_f1/f1_p1.png" />
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content" id="bgc3">
              <div class="content">
                <div class="text">
                  <p class="title">标题1</p>
                  <p class="subtitle">副标题1</p>
                  <a href="javascript:;">
                    查看详情
                    <img src="../../public/images/img_index/img_f1/arrow_right.png" />
                  </a>
                </div>
                <img src="../../public/images/img_index/img_f1/f1_p1.png" />
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content" id="bgc4">
              <div class="content">
                <div class="text">
                  <p class="title">标题1</p>
                  <p class="subtitle">副标题1</p>
                  <a href="javascript:;">
                    查看详情
                    <img src="../../public/images/img_index/img_f1/arrow_right.png" />
                  </a>
                </div>
                <img src="../../public/images/img_index/img_f1/f1_p1.png" />
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
      <!-- -------------------楼层二：最新热门  id='f2'----------- ----- -->
      <div id="f2">
        <div class="slogan">
          <span class="big_slogan">最新热门</span>
          <span class="small_slogan">绝对超值，总有你想不到的优惠</span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <div class="content">
                <a href="javascript:;">
                  <img src="../../public/images/img_index/img_f2/f2_p5.png" />
                  <div class="text">
                    <p class="title">标题1</p>
                    <p class="price">积分1+￥100</p>
                  </div>
                </a>
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content">
              <div class="content">
                <a href="javascript:;">
                  <img src="../../public/images/img_index/img_f2/f2_p5.png" />
                  <div class="text">
                    <p class="title">标题1</p>
                    <p class="price">积分1+￥100</p>
                  </div>
                </a>
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content">
              <div class="content">
                <a href="javascript:;">
                  <img src="../../public/images/img_index/img_f2/f2_p5.png" />
                  <div class="text">
                    <p class="title">标题1</p>
                    <p class="price">积分1+￥100</p>
                  </div>
                </a>
              </div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content">
              <div class="content">
                <a href="javascript:;">
                  <img src="../../public/images/img_index/img_f2/f2_p5.png" />
                  <div class="text">
                    <p class="title">标题1</p>
                    <p class="price">积分1+￥100</p>
                  </div>
                </a>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
      <!-- -------------------楼层三：礼券专区  id='f3'----------------- -->
      <div id="f3" class="slogan_only">
        <div class="slogan">
          <span class="big_slogan">礼券专区</span>
          <span class="more">
            <a href="javascript:;">查看更多</a>
            <img src="../../public/images/img_index/arrow_right.png" />
          </span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <img src="../../public/images/img_index/img_f3/f3_q0.png" />
            </div>
          </el-col>

          <el-col :span="18">
            <el-row :gutter="16">
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f3/f3_q1.png" />
                  </div>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f3/f3_q1.png" />
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f3/f3_q2.png" />
                    <div class="textBottom">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f3/f3_q2.png" />
                    <div class="textBottom">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f3/f3_q2.png" />
                    <div class="textBottom">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f3/f3_q2.png" />
                    <div class="textBottom">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>

      <!-- -------------------楼层四：数码潮流  id='f4'----------------- -->
      <div id="f4" class="slogan_only">
        <div class="slogan">
          <span class="big_slogan">数码潮流</span>
          <span class="more">
            <a href="javascript:;">查看更多</a>
            <img src="../../public/images/img_index/arrow_right.png" />
          </span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <img src="../../public/images/img_index/img_f4/f4_q0.png" />
            </div>
          </el-col>

          <el-col :span="18">
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f4/f4_q1.png" />
                    <div class="textBottom">
                      <p class="title">数码潮流标题1</p>
                      <p class="subtitle">数码潮流副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>

      <!-- -------------------楼层五：办公户外  id='f5'----------------- -->
      <div id="f5" class="slogan_only">
        <div class="slogan">
          <span class="big_slogan">办公户外</span>
          <span class="more">
            <a href="javascript:;">查看更多</a>
            <img src="../../public/images/img_index/arrow_right.png" />
          </span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <img src="../../public/images/img_index/img_f5/f5_q0.png" />
            </div>
          </el-col>

          <el-col :span="18">
            <el-row :gutter="16">
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                  </div>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                    <div class="textBottom">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                    <div class="textBottom">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                    <div class="textBottom">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f5/f5_q1.png" />
                    <div class="textBottom">
                      <p class="title">办公户外标题1</p>
                      <p class="subtitle">办公户外副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>

      <!-- -------------------楼层六：智慧零售  id='f6'----------------- -->

      <div id="f6" class="slogan_only">
        <div class="slogan">
          <span class="big_slogan">智慧零售</span>
          <span class="more">
            <a href="javascript:;">查看更多</a>
            <img src="../../public/images/img_index/arrow_right.png" />
          </span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <img src="../../public/images/img_index/img_f6/f6_q0.png" />
            </div>
          </el-col>

          <el-col :span="18">
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f6/f6_q1.png" />
                    <div class="textBottom">
                      <p class="title">智慧零售标题1</p>
                      <p class="subtitle">智慧零售副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>

      <!-- -------------------楼层七：企业服务  id='f7'----------------- -->
      <div id="f7" class="slogan_only">
        <div class="slogan">
          <span class="big_slogan">企业服务</span>
          <span class="more">
            <a href="javascript:;">查看更多</a>
            <img src="../../public/images/img_index/arrow_right.png" />
          </span>
        </div>
        <el-row :gutter="16">
          <el-col :span="6">
            <div class="grid-content">
              <img src="../../public/images/img_index/img_f7/f7_q0.png" />
            </div>
          </el-col>

          <el-col :span="18">
            <el-row :gutter="16">
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">企业服务标题1</p>
                      <p class="subtitle">企业服务副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                  </div>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content">
                  <div class="contentTop">
                    <div class="textTop">
                      <p class="title">企业服务标题1</p>
                      <p class="subtitle">企业服务副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                    <div class="textBottom">
                      <p class="title">企业服务标题1</p>
                      <p class="subtitle">企业服务副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                    <div class="textBottom">
                      <p class="title">企业服务标题1</p>
                      <p class="subtitle">企业服务副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                    <div class="textBottom">
                      <p class="title">优惠券标题1</p>
                      <p class="subtitle">优惠券副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content">
                  <div class="contentBottom">
                    <img src="../../public/images/img_index/img_f7/f7_q1.png" />
                    <div class="textBottom">
                      <p class="title">企业服务标题1</p>
                      <p class="subtitle">企业服务副标题1</p>
                      <p class="price">￥10</p>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
    </div>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
import Carousel from '../components/Carousel.vue'
export default {
  components: {
    Carousel
  }
}
</script>

<!-- 三.CSS样式 -->
<style>
body {
  background-color: #f5f5f5 !important;
}
</style>
<style scoped>
/* 0.基本样式 */
body {
  background-color: #f5f5f5 !important;
}
#container {
  width: 1200px;
  margin: 0 auto;
  margin-top: 26px;
}
div.slogan {
  margin-bottom: 16px;
}

.big_slogan {
  color: #333333;
  padding-right: 20px;
  font-size: 24px;
  margin-left: 10px;
  margin-top: 46px;
  margin-bottom: 16px;
}
span.small_slogan {
  color: #666666;
  font-size: 14px;
}
.more a {
  margin-right: 6px;
  margin-left: 988px;
  font-size: 16px;
  color: #666666;
}
.more img {
  width: 10px;
  height: 20px;
  margin-bottom: -4px;
}
/* 栅格布局样式 */
.el-row {
  margin-bottom: 16px;
}
.grid-content {
  min-height: 36px;
  background-color: #f9fafc;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}

/* 1.一楼样式 */
div#f1 .grid-content {
  width: 288px;
  height: 190px;
}
div#f1 #bgc1 {
  background-color: #ffe7e2;
}
div#f1 #bgc2 {
  background-color: #eff2f8;
}
div#f1 #bgc3 {
  background-color: #d0f4ff;
}
div#f1 #bgc4 {
  background-color: #d5dde0;
}
div#f1 div.content {
  width: 272px;
  height: 143px;
  margin: 37px 2px 10px 14px;
}
div#f1 a {
  width: 57px;
  height: 12px;
  color: #666666;
  font-size: 14px;
  position: relative;
  top: 67px;
}
div#f1 a > img {
  width: 8px;
  height: 16px;
  margin-bottom: -4px;
}
div#f1 div.content > img {
  width: 100px;
  height: 100px;
  margin-left: 160px;
  margin-top: -28px;
}
div#f1 p.title {
  color: #666666;
  font-size: 16px;
  margin-bottom: 8px;
}
div#f1 p.subtitle {
  color: #666666;
  font-size: 12px;
}
div.grid-content:before {
  content: '';
  display: table;
}
/* 2.二楼样式 */
div#f2 .grid-content {
  width: 288px;
  height: 336px;
}
div#f2 div.content {
  width: 228px;
  height: 241px;
  margin: 43px 30px 52px 30px;
}
div#f2 img {
  width: 228px;
  height: 228px;
}
div#f2 .text {
  text-align: center;
  margin-top: 10px;
}
div#f2 .title {
  color: #666666;
  font-size: 14px;
}
div#f2 .price {
  color: #ef4949;
  font-size: 15px;
}
#f3 .contentBottom {
  margin-top: 63px;
}
/* 3.三楼及以下楼层公用的样式 */
#f3 .contentBottom img {
  width: 173px;
  height: 105px;
  margin-left: 0px !important;
}
div.slogan_only {
  width: 1200px;
  height: 590px;
}
div.slogan_only .grid-content {
  /* width: 212px; */
  height: 300px;
}
div.slogan_only .title {
  color: #333333;
  font-size: 16px;
  font-weight: 400;
}
div.slogan_only .subtitle {
  color: #666666;
  font-size: 14px;
  font-weight: 400;
  margin-top: 6px;
  margin-bottom: 6px;
}
div.slogan_only .price {
  color: #ef4949;
  font-size: 15px;
  font-weight: 400;
}

.contentTop {
  width: 155px;
  height: 263px;
  margin: 0 auto;
  margin-top: 25px;
}
.contentTop > img {
  width: 155px;
  height: 185px;
  margin-top: -185px;
  margin-left: 6px;
  position: relative;
  top: -149px;
}
.textTop {
  width: 200px;
  height: 185px;
  text-align: center;
  vertical-align: middle;
  display: table-cell;
  padding-top: 131px;
  position: relative;
  top: 8px;
}
.contentBottom {
  width: 173px;
  height: 192px;
  text-align: center;
  margin: 0 auto;
}
.contentBottom > img {
  width: 212px;
  height: 212px;
  margin-left: -20px;
}
.textBottom {
  position: relative;
  top: 5px;
}
#f5 .contentTop > img {
  width: 440px;
  height: 212px;
  margin-left: -142px;
  margin-top: -192px;
}
#f7 .contentTop > img {
  width: 440px;
  height: 212px;
  margin-left: -142px;
  margin-top: -192px;
}
</style>