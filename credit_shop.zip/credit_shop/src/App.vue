<template>
  <div id="app">
    <div id="nav"></div>
     <my-header></my-header>
    
    <router-view/>
  </div>
</template>

<script>
  import MyHeader from './components/MyHeader.vue'
  export default {}
</script>  

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
#nav {
  padding: 0px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
