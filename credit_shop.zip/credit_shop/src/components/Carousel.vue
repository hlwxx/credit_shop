<template>
  <div class="block">
    <el-carousel height="150px">
      <el-carousel-item v-for="(item,index) in dataimg" :key="index">
        <h3 class="small">
          <img :src='item' />
        </h3>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script>
  export default {
    data(){
      return{ 
        dataimg: []
      }
    },
    methods:{
      getImgUrl(){
        for(var i=0;i<3;i++){
          var img = require('../../public/images/img_index/banner/banner'+(i+1)+'.png');
          this.dataimg.push(img);
        }
      }
    },
    mounted(){
      this.getImgUrl();
    }
  }
</script>

<style>
  .el-carousel__container{
    width:100%;
    height: 460px !important;
  }
  .el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
  h3.small>img {
    width: 100%;
    height: 460px;
  }
</style>