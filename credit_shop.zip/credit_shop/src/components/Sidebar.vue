<!-- <h1>侧边栏子组件页面</h1>-->
<!-- 一.HTML代码 -->
<template>
  <main id="content">
    <!-- 左侧导航栏 -->
    <el-row class="tac">
      <el-col :span="4">
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          @close="handleClose"
          text-color="#333333"
          active-text-color="#428BCA"
        >
          <el-submenu index="1">
            <template slot="title">
              <span>账号管理</span>
            </template>
            <el-menu-item-group>
              <router-link to="./personal">
                <el-menu-item index="1-1">个人中心</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-2">消息通知</el-menu-item>
              </router-link>
              <router-link to="./account">
                <el-menu-item index="1-3">账号信息</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-4">地址管理</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-5">账号安全</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-6">我的积分</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-7">我的卡券</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-8">我的收藏</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-9">我的足迹</el-menu-item>
              </router-link>
            </el-menu-item-group>
          </el-submenu>
          <el-submenu index="2">
            <template slot="title">
              <span>交易管理</span>
            </template>
            <el-menu-item-group>
              <router-link to="./personal">
                <el-menu-item index="1-10">订单管理</el-menu-item>
              </router-link>
              <router-link to="./personal">
                <el-menu-item index="1-11">退款管理</el-menu-item>
              </router-link>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-col>
    </el-row>
  </main>
</template>

<!-- 二.JS脚本 -->
<script>
export default {
  // 子组件定义自定义属性
  props: ['sidebar'],
  data() {
    return {}
  },
  methods: {
    // 左侧导航栏的方法
    handleOpen(key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath)
    }
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
.el-col.el-col-4 {
  border: 1px solid #eeeeee;
  width: 224px;
}
.el-submenu__title * {
  font-size: 16px;
  font-weight: bold;
}
::v-deep .el-submenu__title {
  text-align: center;
}
li.el-menu-item {
  text-align: center;
  color: #666666 !important;
}
</style>