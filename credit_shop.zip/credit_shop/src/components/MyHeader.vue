<!-- <h1>头部页面</h1>-->
<!-- 一.HTML代码 -->
<template>
  <header>
    <div id="header_container">
      <!-- 1.上面分区：logo+搜索框+查看积分按钮 -->
      <div id="top">
        <router-link :to="{path:'/'}" class="navbar-brand" id="logo">
          <img src="../../public/images/img_header/logo.png" />
        </router-link>
        <div id="search">
          <!-- <el-dropdown>
            <span class="el-dropdown-link">
              全部分类
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>潮流数码</el-dropdown-item>
              <el-dropdown-item>办公户外</el-dropdown-item>
              <el-dropdown-item>智慧零售</el-dropdown-item>
              <el-dropdown-item>企业服务</el-dropdown-item>
              <el-dropdown-item>礼券专区</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>-->

          <el-row id="input">
            <el-col :span="12">
              <el-autocomplete
                class="inline-input"
                v-model="state"
                :fetch-suggestions="querySearch"
                prefix-icon="el-icon-search"
                placeholder="请输入你想搜索的商品"
                @select="handleSelect"
                clearable
              ></el-autocomplete>
            </el-col>
          </el-row>
          <el-button type="primary">搜索</el-button>
        </div>
        <div id="btn">
          <!-- <el-button type="primary" plain id="credit" class="fs14" icon="jifen iconjifen"> -->
          <el-button type="primary" plain id="credit" class="fs14">
            <router-link to="/personal">
              <span class="fs14">登录</span>
            </router-link>
          </el-button>
          <!-- <el-button type="primary" plain id="cart" icon="el-icon-shopping-cart-2"> -->
          <el-button type="primary" plain id="cart">
            <router-link to="/register">
              <span class="fs14">注册</span>
            </router-link>
          </el-button>
        </div>
      </div>

      <!-- 2.下面分区：热搜推荐+分类导航栏 -->
      <div id="bottom">
        <ul class="refer">
          <li>
            <a href="javascript:;">硬盘</a>
          </li>
          <li>
            <a href="javascript:;">耳机</a>
          </li>
          <li>
            <a href="javascript:;">充电宝</a>
          </li>
          <li>
            <a href="javascript:;">鼠标</a>
          </li>
          <li>
            <a href="javascript:;">双肩包</a>
          </li>
          <!-- <li>
            <a href="javascript:;">风扇</a>
          </li>
          <li>
            <a href="javascript:;">折叠桌</a>
          </li>
          <li>
            <a href="javascript:;">被子</a>
          </li>-->
        </ul>

        <el-menu
          :default-active="activeIndex"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
        >
          <el-submenu index="1" class="category">
            <template slot="title">
              <router-link to="./products">
                <img src="../../public/images/img_header/products_all.png" />全部商品
              </router-link>
            </template>
            <el-menu-item index="1-1">
              <img src="../../public/images/img_header/digital.png" class="icon_position" />潮流数码
            </el-menu-item>
            <el-menu-item index="1-2">
              <img src="../../public/images/img_header/office.png" class="icon_position" />办公户外
            </el-menu-item>
            <el-menu-item index="1-3">
              <img src="../../public/images/img_header/retail.png" class="icon_position" />智慧零售
            </el-menu-item>
            <el-menu-item index="1-4">
              <img src="../../public/images/img_header/service.png" class="icon_position" />企业服务
            </el-menu-item>
            <el-menu-item index="1-5">
              <img src="../../public/images/img_header/coupon.png" class="icon_position" />礼券专区
            </el-menu-item>
          </el-submenu>
          <div id="pages">
            <el-menu-item index="2" class="nav">
              <router-link :to="{path:'/'}">首页</router-link>
            </el-menu-item>
            <el-menu-item index="3" class="nav">
              <a href="javascript:;" target="_blank">潮流数码</a>
            </el-menu-item>
            <el-menu-item index="4" class="nav">
              <a href="javascript:;" target="_blank">办公户外</a>
            </el-menu-item>
            <el-menu-item index="5" class="nav">
              <a href="javascript:;" target="_blank">智慧零售</a>
            </el-menu-item>
            <el-menu-item index="6" class="nav">
              <a href="javascript:;" target="_blank">企业服务</a>
            </el-menu-item>
            <el-menu-item index="7" class="nav">
              <a href="javascript:;" target="_blank">礼券专区</a>
            </el-menu-item>
            <el-menu-item index="8" class="nav">
              <a href="javascript:;" target="_blank">我可兑换</a>
            </el-menu-item>
          </div>
        </el-menu>
      </div>
    </div>
  </header>
</template>

<!-- 二.JS脚本 -->
<script>
export default {
  data() {
    return {
      search_items: [],
      state: '',
      activeIndex: '1'
    }
  },
  // 输入后匹配输入建议
  methods: {
    querySearch(queryString, cb) {
      var search_items = this.search_items
      var results = queryString
        ? search_items.filter(this.createFilter(queryString))
        : search_items
      // 调用 callback 返回建议列表的数据
      cb(results)
    },
    createFilter(queryString) {
      return restaurant => {
        return (
          restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) ===
          0
        )
      }
    },
    loadAll() {
      // 输入搜索提示
      // return [{ value: '积分' }, { value: '实物' }, { value: '服务' }]
    },
    handleSelect(item) {
      console.log(item)
    }
  },
  mounted() {
    // this.search_items = this.loadAll()
  }
}
</script>

<!-- 三.CSS样式 -->
<style scoped>
/* 0.通用样式： */
::v-deep * {
  margin: 0;
  padding: 0;
}
header ::v-deep {
  background-color: #ffffff !important;
}
::v-deep #header_container {
  width: 1200px;
  height: 178px;
  margin: 0 auto;
}
/* 1.上面分区样式 */
::v-deep div#top {
  width: 1200px;
  height: 87px;
  padding-top: 48px;
}
::v-deep a#logo {
  padding-top: 50px;
}
::v-deep div#top #search {
  margin-top: -55px;
  margin-left: 519px;
  width: 432px;
  height: 38px;
  display: flex;
  align-items: center;
  border-radius: 6px;
  border: 1px solid rgba(238, 238, 238, 1);
}
::v-deep .el-dropdown-link {
  cursor: pointer;
  color: #666666;
}
::v-deep .el-icon-arrow-down {
  font-size: 12px;
}

::v-deep div#search button {
  width: 88px;
  height: 40px;
  position: relative;
  border: 0;
  background-color: #428bca;
}
.el-icon-search:before {
  margin-left: 10px;
}
::v-deep div#search .el-dropdown {
  padding-left: 15px;
}
::v-deep .el-dropdown:after {
  content: '';
  width: 1px;
  height: 16px;
  background: #eeeeee;
  position: absolute;
  margin-left: 8px;
}

::v-deep .el-col-12 {
  width: 366px !important;
}
::v-deep .el-input--prefix .el-input__inner {
  padding-left: 30px;
  border: 0 !important;
  background: transparent !important;
}
::v-deep .el-input__inner {
  border: 0 !important;
  background: transparent !important;
  padding: 0 21px !important;
}

::v-deep .el-button {
  border-radius: 0 6px 6px 0 !important;
}
::v-deep .el-button--primary.is-plain {
  width: 110px;
  height: 38px;
  position: relative;
  top: -39px;
  right: -1090px;
  border-radius: 6px !important;
  color: #428bca !important;
  background-color: #ffffff !important;
  line-height: 10px;
  font-size: 18px;
}
::v-deep .el-input--suffix .el-input__inner {
  padding-right: 160px !important;
  margin-left: 20px;
}
::v-deep #credit img {
  width: 16px;
  height: 18px;
  margin-right: 5px;
}
::v-deep span.el-dropdown-link.el-dropdown-selfdefine {
  margin-right: 8px !important;
}
::v-deep .el-icon-arrow-down:before {
  margin-left: -1px;
}
::v-deep .iconjifen:before {
  margin-left: -6px;
  position: relative;
  top: 3px;
}
.fs14 {
  font-size: 14px !important;
}
span.fs14 {
  position: relative;
  color: #428bca;
}
#cart .fs14 {
  position: relative;
  /* top: -3px; */
}
::v-deep .el-icon-shopping-cart-2:before {
  margin-left: -12px !important;
  position: relative;
  top: -2px;
}

button#credit {
  position: relative;
  /* top: -43px; */
}
button#cart {
  position: relative;
  top: -39px;
}
div#btn {
  margin-left: -121px;
}
/* 2.下面分区样式 */
::v-deep ul.refer {
  width: 392px;
  height: 13px;
  margin-left: 657px;
  font-size: 14px;
  color: #999999;
  margin-top: -45px;
  position: relative;
  left: -118px;
}

::v-deep ul.refer li {
  float: left;
  padding-right: 18px;
}
::v-deep ul.refer li:last-child {
  padding-right: 0px;
}
::v-deep li.el-menu-item.nav {
  float: left;
}
::v-deep div#bottom ul a {
  color: #999999;
}
.el-menu--horizontal .el-menu .el-menu-item,
.el-menu--horizontal .el-menu .el-submenu__title {
  color: #333333;
  height: 40px;
}
::v-deep div#bottom .el-menu {
  background-color: transparent !important;
  border-right: 0 !important;
  width: 996px;
  margin: 0px;
}
::v-deep .el-menu.el-menu--horizontal {
  border-bottom: 0 !important;
}
::v-deep .el-submenu__title {
  background-color: #428bca !important;
  width: 200px;
  height: 40px !important;
  text-align: center;
  line-height: 40px !important;
}
::v-deep .category .el-icon-arrow-down:before {
  content: '' !important;
}

::v-deep div.el-submenu__title a {
  color: #f5f5f5 !important;
  font-size: 16px;
}
::v-deep div#bottom img {
  margin-right: 14px;
}
::v-deep .icon_position {
  margin-right: 14px !important;
  margin-left: 39px;
}
::v-deep li.el-menu-item.nav {
  height: 40px;
  line-height: 40px;
  margin-left: 12px;
  padding-right: 22px !important;
}
::v-deep ul.el-menu-demo.el-menu--horizontal.el-menu {
  top: 29px;
}

li.el-menu-item {
  background-color: rgba(255, 255, 255, 0.6) !important;
}
#pages a {
  color: #333333 !important;
  font-size: 16px;
}
</style>

<style>
ul.el-menu.el-menu--popup.el-menu--popup-bottom-start {
  margin-top: -3px !important;
  background-color: rgba(255, 255, 255, 0.6) !important;
  padding: 0 0 !important;
}
</style>